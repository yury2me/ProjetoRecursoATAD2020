var files_dup =
[
    [ "commands.c", "commands_8c.html", "commands_8c" ],
    [ "commands.h", "commands_8h.html", "commands_8h" ],
    [ "list.h", "list_8h.html", "list_8h" ],
    [ "listArrayList.c", "list_array_list_8c.html", "list_array_list_8c" ],
    [ "listElem.c", "list_elem_8c.html", "list_elem_8c" ],
    [ "listElem.h", "list_elem_8h.html", "list_elem_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "map.h", "map_8h.html", "map_8h" ],
    [ "mapArrayList.c", "map_array_list_8c.html", "map_array_list_8c" ],
    [ "mapElem.c", "map_elem_8c.html", "map_elem_8c" ],
    [ "mapElem.h", "map_elem_8h.html", "map_elem_8h" ],
    [ "movie.c", "movie_8c.html", "movie_8c" ],
    [ "movie.h", "movie_8h.html", "movie_8h" ],
    [ "rating.c", "rating_8c.html", "rating_8c" ],
    [ "rating.h", "rating_8h.html", "rating_8h" ]
];