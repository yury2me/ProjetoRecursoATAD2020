var rating_8h =
[
    [ "rating", "structrating.html", "structrating" ],
    [ "PtRating", "rating_8h.html#a11de31c21a6104ff5a3a4113488fd2fa", null ],
    [ "Rating", "rating_8h.html#a210df0a1f65e713102eb8eeb289280e9", null ],
    [ "calculateScore", "rating_8h.html#aa33e4a1405f298466a07038dae42d08a", null ],
    [ "copyRating", "rating_8h.html#abfa320e9425bbb8b914821c634ef7d2c", null ],
    [ "createEmptyRating", "rating_8h.html#a9151ffdaa89fab035c8992cb947525ce", null ],
    [ "createRating", "rating_8h.html#aaf5399546ffc07516e7674bb55528208", null ],
    [ "printPtRating", "rating_8h.html#ab7ebb91a91ced93018feab2e0db04e4f", null ],
    [ "printRating", "rating_8h.html#ad1f90d4dbec308d12122ba56d441f3b8", null ]
];