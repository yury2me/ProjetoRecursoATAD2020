var searchData=
[
  ['genre_24',['genre',['../structmovie.html#a56bd4579b9b1a0545adebad1335257bb',1,'movie']]],
  ['getmatrixcellvalue_25',['getMatrixCellValue',['../commands_8c.html#a9a5a067405dc7243394311c58cabc902',1,'getMatrixCellValue(PtList list, int year, char *genre):&#160;commands.c'],['../commands_8h.html#a9a5a067405dc7243394311c58cabc902',1,'getMatrixCellValue(PtList list, int year, char *genre):&#160;commands.c']]]
];
