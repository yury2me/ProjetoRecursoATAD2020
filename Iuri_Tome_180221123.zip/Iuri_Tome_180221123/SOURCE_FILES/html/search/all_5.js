var searchData=
[
  ['femalevotes_22',['femaleVotes',['../structrating.html#ad2d65f9c73617106f35ff8d74b6f650b',1,'rating']]],
  ['firstelementselector_23',['firstElementSelector',['../commands_8c.html#a261e11ee46efb3057d406ccfa38ed4a4',1,'firstElementSelector(char *sequence):&#160;commands.c'],['../commands_8h.html#a261e11ee46efb3057d406ccfa38ed4a4',1,'firstElementSelector(char *sequence):&#160;commands.c']]]
];
