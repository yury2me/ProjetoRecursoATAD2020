var searchData=
[
  ['rating_197',['rating',['../commands_8c.html#a3ddcec19986f651a9d45695f4290469a',1,'rating(PtList list, PtMap map):&#160;commands.c'],['../commands_8h.html#a3ddcec19986f651a9d45695f4290469a',1,'rating(PtList list, PtMap map):&#160;commands.c']]],
  ['removechar_198',['removeChar',['../commands_8c.html#ad41d6217a793c671ca1f09c15392643b',1,'removeChar(char *str, char c):&#160;commands.c'],['../commands_8h.html#ad41d6217a793c671ca1f09c15392643b',1,'removeChar(char *str, char c):&#160;commands.c']]]
];
