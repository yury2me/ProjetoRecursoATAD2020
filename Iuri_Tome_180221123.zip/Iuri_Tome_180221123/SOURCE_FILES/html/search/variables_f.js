var searchData=
[
  ['year_228',['year',['../structmovie.html#ad4a699aa2496314cbffd881207eaf313',1,'movie']]]
];
