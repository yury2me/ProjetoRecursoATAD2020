var searchData=
[
  ['getmatrixcellvalue_158',['getMatrixCellValue',['../commands_8c.html#a9a5a067405dc7243394311c58cabc902',1,'getMatrixCellValue(PtList list, int year, char *genre):&#160;commands.c'],['../commands_8h.html#a9a5a067405dc7243394311c58cabc902',1,'getMatrixCellValue(PtList list, int year, char *genre):&#160;commands.c']]]
];
