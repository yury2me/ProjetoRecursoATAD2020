var searchData=
[
  ['genre_212',['genre',['../structmovie.html#a56bd4579b9b1a0545adebad1335257bb',1,'movie']]]
];
