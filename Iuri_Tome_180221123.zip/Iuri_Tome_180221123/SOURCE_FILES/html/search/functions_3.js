var searchData=
[
  ['firstelementselector_157',['firstElementSelector',['../commands_8c.html#a261e11ee46efb3057d406ccfa38ed4a4',1,'firstElementSelector(char *sequence):&#160;commands.c'],['../commands_8h.html#a261e11ee46efb3057d406ccfa38ed4a4',1,'firstElementSelector(char *sequence):&#160;commands.c']]]
];
