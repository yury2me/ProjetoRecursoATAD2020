var searchData=
[
  ['femalevotes_211',['femaleVotes',['../structrating.html#ad2d65f9c73617106f35ff8d74b6f650b',1,'rating']]]
];
