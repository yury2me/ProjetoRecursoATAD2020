var searchData=
[
  ['string_241',['String',['../main_8c.html#a0801bccaefbb788a7e916447dd1fa845',1,'main.c']]]
];
