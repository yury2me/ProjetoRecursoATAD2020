var searchData=
[
  ['value_226',['value',['../structkey_value.html#a3e828102e73060c7e8ea30e2dd9d3d27',1,'keyValue']]],
  ['votes_227',['votes',['../structrating.html#a5f3d963af81f3797ea16c26567f093e3',1,'rating']]]
];
