var searchData=
[
  ['romance_220',['ROMANCE',['../results_8txt.html#a66811a76109c0600adaf5c27b600f516',1,'results.txt']]]
];
