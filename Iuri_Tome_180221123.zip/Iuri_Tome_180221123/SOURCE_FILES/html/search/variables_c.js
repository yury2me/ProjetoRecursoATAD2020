var searchData=
[
  ['thriller_223',['THRILLER',['../results_8txt.html#a501d575d992c9ea4ea277606e697efec',1,'results.txt']]],
  ['title_224',['title',['../structmovie.html#acfc10109ed4262b3d2c88492c8efcbbc',1,'movie']]]
];
