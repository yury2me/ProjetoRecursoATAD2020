var searchData=
[
  ['thriller_116',['THRILLER',['../results_8txt.html#a501d575d992c9ea4ea277606e697efec',1,'results.txt']]],
  ['title_117',['title',['../structmovie.html#acfc10109ed4262b3d2c88492c8efcbbc',1,'movie']]],
  ['top5_118',['top5',['../commands_8c.html#a21f90daf31490b2021d5cfbaeb0b3754',1,'top5(PtList list, PtMap map):&#160;commands.c'],['../commands_8h.html#a21f90daf31490b2021d5cfbaeb0b3754',1,'top5(PtList list, PtMap map):&#160;commands.c']]]
];
