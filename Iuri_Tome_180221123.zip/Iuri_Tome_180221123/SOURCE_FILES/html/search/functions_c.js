var searchData=
[
  ['year_202',['year',['../commands_8c.html#af119b7cf653eeaa2a07436c732474196',1,'year(PtList list, PtMap map):&#160;commands.c'],['../commands_8h.html#af119b7cf653eeaa2a07436c732474196',1,'year(PtList list, PtMap map):&#160;commands.c']]]
];
