var searchData=
[
  ['director_207',['director',['../structmovie.html#a655e80e644e2fad152db01c0361cd5cc',1,'movie']]],
  ['drama_208',['DRAMA',['../results_8txt.html#ab77db8bf983bea7e63e4323b86935822',1,'results.txt']]],
  ['duration_209',['duration',['../structmovie.html#af607dbea6945b77c5aac615a2ff15be3',1,'movie']]]
];
