var searchData=
[
  ['best5selector_145',['best5Selector',['../commands_8c.html#a0d422825061d6c39cd482862c36253a4',1,'best5Selector(PtMap map, PtList *categoryList):&#160;commands.c'],['../commands_8h.html#a0d422825061d6c39cd482862c36253a4',1,'best5Selector(PtMap map, PtList *categoryList):&#160;commands.c']]]
];
