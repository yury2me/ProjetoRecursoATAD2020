var commands_8h =
[
    [ "best5Selector", "commands_8h.html#a0d422825061d6c39cd482862c36253a4", null ],
    [ "clear", "commands_8h.html#a829d44099ef540e6eb299a7a4cf29e9c", null ],
    [ "country", "commands_8h.html#a2cf038272e90db6eb836258bdf6897e6", null ],
    [ "createNewKey", "commands_8h.html#a37cac7b4c2e070a79943e8db74fd527c", null ],
    [ "firstElementSelector", "commands_8h.html#a261e11ee46efb3057d406ccfa38ed4a4", null ],
    [ "getMatrixCellValue", "commands_8h.html#a9a5a067405dc7243394311c58cabc902", null ],
    [ "loadm", "commands_8h.html#ac693feb20d9c6ed2efc889a4facf00eb", null ],
    [ "loadr", "commands_8h.html#abf4bcc6225eea0df0ccc207e4165d03f", null ],
    [ "matrix", "commands_8h.html#af3c193bf328cd2f8fdcad9f1e5775c3b", null ],
    [ "printMatrix", "commands_8h.html#ae2d9102a910f14183384cb1445a5d330", null ],
    [ "printTop5List", "commands_8h.html#a4efcd58440e64cb63091ca45805f4154", null ],
    [ "quitProg", "commands_8h.html#a3c0600d8e8e7e4e9cd74d89731653ae9", null ],
    [ "rating", "commands_8h.html#a3ddcec19986f651a9d45695f4290469a", null ],
    [ "removeChar", "commands_8h.html#ad41d6217a793c671ca1f09c15392643b", null ],
    [ "sameDir", "commands_8h.html#a501b1ffb3d86c35c72c2fba1d891a986", null ],
    [ "split", "commands_8h.html#ab383150b853d46993033b8f5cecf2073", null ],
    [ "top5", "commands_8h.html#a21f90daf31490b2021d5cfbaeb0b3754", null ],
    [ "year", "commands_8h.html#af119b7cf653eeaa2a07436c732474196", null ]
];