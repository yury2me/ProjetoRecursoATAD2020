var rating_8c =
[
    [ "calculateScore", "rating_8c.html#aa33e4a1405f298466a07038dae42d08a", null ],
    [ "copyRating", "rating_8c.html#abfa320e9425bbb8b914821c634ef7d2c", null ],
    [ "createEmptyRating", "rating_8c.html#a9151ffdaa89fab035c8992cb947525ce", null ],
    [ "createRating", "rating_8c.html#aaf5399546ffc07516e7674bb55528208", null ],
    [ "printPtRating", "rating_8c.html#ab7ebb91a91ced93018feab2e0db04e4f", null ],
    [ "printRating", "rating_8c.html#ad1f90d4dbec308d12122ba56d441f3b8", null ]
];