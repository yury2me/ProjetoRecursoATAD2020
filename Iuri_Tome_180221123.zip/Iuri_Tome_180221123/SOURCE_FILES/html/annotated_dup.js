var annotated_dup =
[
    [ "keyValue", "structkey_value.html", "structkey_value" ],
    [ "listImpl", "structlist_impl.html", "structlist_impl" ],
    [ "mapImpl", "structmap_impl.html", "structmap_impl" ],
    [ "mapKey", "structmap_key.html", "structmap_key" ],
    [ "movie", "structmovie.html", "structmovie" ],
    [ "rating", "structrating.html", "structrating" ]
];