var structmovie =
[
    [ "country", "structmovie.html#a9f7844378456d5cdf45021df3730631f", null ],
    [ "director", "structmovie.html#a655e80e644e2fad152db01c0361cd5cc", null ],
    [ "duration", "structmovie.html#af607dbea6945b77c5aac615a2ff15be3", null ],
    [ "genre", "structmovie.html#a56bd4579b9b1a0545adebad1335257bb", null ],
    [ "id", "structmovie.html#aba02760996f17126c419158334b607df", null ],
    [ "title", "structmovie.html#acfc10109ed4262b3d2c88492c8efcbbc", null ],
    [ "year", "structmovie.html#ad4a699aa2496314cbffd881207eaf313", null ]
];