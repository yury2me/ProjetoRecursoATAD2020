var structrating =
[
    [ "femaleVotes", "structrating.html#ad2d65f9c73617106f35ff8d74b6f650b", null ],
    [ "maleVotes", "structrating.html#a05c92105dcc1b0c92462be1d3c8033cd", null ],
    [ "movieId", "structrating.html#aa42a88545b4eee72373bfb8f57cbe533", null ],
    [ "score", "structrating.html#a4ed231214a1eb82d59a3977743e3ac87", null ],
    [ "votes", "structrating.html#a5f3d963af81f3797ea16c26567f093e3", null ]
];